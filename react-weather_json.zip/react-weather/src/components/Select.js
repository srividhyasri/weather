import React from "react";

const SelectComponent = (props) => {
    const stateList = props.stateList;
    const stateArr = Object.keys(stateList);
        let stateListDp = stateArr.length > 0
            && stateArr.map((item, i) => {
                console.log(item);
            return (
               <option key={i} value={item}>{item}</option>
           )
        }, this);

    
        return (
            <div>
                <select onChange={this.selectedCountry}>
                    {stateListDp}
                </select>
            </div>
        );
    

}

export default SelectComponent;