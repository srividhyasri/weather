import React from "react";

const CityComponent = (props) => {
    const cityList = props.stateList;
    const cityArr = Object.keys(stateList);

        let stateListDp = stateArr.length > 0
            && stateArr.map((item, i) => {
                console.log(item);
            return (
               <option key={i} value={item}>{item}</option>
           )
        }, this);

    
        return (
            <div>
                <select>
                    {cityListDp}
                </select>
            </div>
        );
    

}

export default CityComponent;