export default {

    // actions
    'UPDATE_STATE': 'UPDATE_STATE',
    'UPDATE_CITY': 'UPDATE_CITY',
    'STORE_WEATHER_DATA': 'STORE_WEATHER_DATA'
}